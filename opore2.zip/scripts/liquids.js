const core = require("core");

for (var i = 0; i < 10; i++) core.addLiquid();
