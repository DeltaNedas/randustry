const core = require("core");
const count = 10;

for (var i = 0; i < count; i++) {
	core.addBlock();
}
