this.global.randustry = {
	registered: {}
};

require("items")
require("liquids")
require("blocks")
